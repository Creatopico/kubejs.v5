StartupEvents.registry('item', e => {
    e.create('ammonia_bottle').displayName('Бутылочка аммиака')
})
  