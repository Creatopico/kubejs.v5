StartupEvents.registry('item', e => {
    e.create('lens').displayName('Линза')
})
  