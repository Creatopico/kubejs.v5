StartupEvents.registry('item', e => {
    e.create('steel_sheet').displayName('Стальная пластина')
})
  