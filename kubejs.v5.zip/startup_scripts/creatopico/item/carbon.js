StartupEvents.registry('item', e => {
    e.create('carbon').displayName('Углерод')
})
  