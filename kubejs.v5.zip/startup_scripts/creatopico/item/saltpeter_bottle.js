StartupEvents.registry('item', e => {
    e.create('saltpeter_bottle').displayName('Бутылочка селитры')
})
  