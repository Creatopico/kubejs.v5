StartupEvents.registry('item', e => {
    e.create('guano').displayName('Гуано')
})
  