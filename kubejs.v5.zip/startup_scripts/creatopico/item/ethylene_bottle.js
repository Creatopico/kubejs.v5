StartupEvents.registry('item', e => {
    e.create('ethylene_bottle').displayName('Бутылочка этилена')
})
  