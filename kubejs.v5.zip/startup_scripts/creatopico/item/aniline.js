StartupEvents.registry('item', e => {
    e.create('aniline').displayName('Анилин')
})
  