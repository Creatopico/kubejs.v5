StartupEvents.registry('item', e => {
    e.create('magnetic_pyrite').displayName('Магнитный колчедан')
})
  