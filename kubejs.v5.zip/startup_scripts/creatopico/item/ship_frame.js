StartupEvents.registry('item', e => {
    e.create('ship_frame').displayName('Остов корабля')
})
  