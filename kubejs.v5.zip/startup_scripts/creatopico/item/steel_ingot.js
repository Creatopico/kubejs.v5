StartupEvents.registry('item', e => {
    e.create('steel_ingot').displayName('Стальной слиток')
})
  