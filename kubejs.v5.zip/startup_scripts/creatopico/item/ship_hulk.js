StartupEvents.registry('item', e => {
    e.create('ship_hulk').displayName('Обшивка корабля')
})
  