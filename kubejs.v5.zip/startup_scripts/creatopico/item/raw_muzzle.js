StartupEvents.registry('item', e => {
    e.create('raw_muzzle').displayName('Незаконченное дуло')
})
  