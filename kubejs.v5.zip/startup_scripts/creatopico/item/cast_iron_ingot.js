StartupEvents.registry('item', e => {
    e.create('cast_iron_ingot').displayName('Чугунный слиток')
})
  