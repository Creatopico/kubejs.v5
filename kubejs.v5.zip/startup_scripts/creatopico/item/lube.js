StartupEvents.registry('item', e => {
    e.create('lube').displayName('Баночка смазочного масла')
})
  