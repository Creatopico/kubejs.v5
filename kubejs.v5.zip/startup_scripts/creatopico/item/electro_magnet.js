StartupEvents.registry('item', e => {
    e.create('electro_magnet').displayName('Электромагнит')
})
  