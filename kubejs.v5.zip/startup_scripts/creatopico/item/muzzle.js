StartupEvents.registry('item', e => {
    e.create('muzzle').displayName('Дуло')
})
  