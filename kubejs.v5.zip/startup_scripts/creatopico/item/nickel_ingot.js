StartupEvents.registry('item', e => {
    e.create('nickel_ingot').displayName('Никелевый слиток')
})
  