StartupEvents.registry('item', e => {
    e.create('dead_rattlesnake').displayName('Мертвая гремучая змея')
})
  