StartupEvents.registry('item', e => {
    e.create('fat').displayName('Жир')
})
  