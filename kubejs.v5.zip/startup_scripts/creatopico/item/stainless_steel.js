StartupEvents.registry('item', e => {
    e.create('stainless_steel').displayName('Нержавеющая сталь')
})
  