StartupEvents.registry('item', e => {
    e.create('bear_skin').displayName('Шкура медведя')
})
  