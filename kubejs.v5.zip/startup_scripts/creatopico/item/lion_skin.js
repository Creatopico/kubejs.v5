StartupEvents.registry('item', e => {
    e.create('lion_skin').displayName('Шкура льва')
})
  