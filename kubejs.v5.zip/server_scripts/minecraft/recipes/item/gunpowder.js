ServerEvents.recipes(event => {
    event.shapeless('1x minecraft:gunpowder', [ // arg 1: output
      'minecraft:charcoal',
      'kubejs:saltpeter_bottle'
    ])
})
