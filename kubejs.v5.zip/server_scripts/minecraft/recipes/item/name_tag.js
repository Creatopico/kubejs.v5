ServerEvents.recipes(event => {
    event.shapeless('1x minecraft:name_tag', [ // arg 1: output
      'minecraft:paper',
      'kubejs:carbon_fiber'
    ])
})
