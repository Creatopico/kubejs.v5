LootJS.modifiers((event) => {
    event
        .addEntityLootModifier("naturalist:elephant")
        .addLoot("kubejs:fat");
});