LootJS.modifiers((event) => {
    event
        .addEntityLootModifier("naturalist:hippopotamus")
        .addLoot("kubejs:fat");
});