LootJS.modifiers((event) => {
    event
        .addEntityLootModifier("minecraft:bat")
        .addLoot("kubejs:guano");
});