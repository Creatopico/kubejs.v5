ServerEvents.recipes(event => {
    event.shapeless('1x kubejs:advanced_microcircuit', [ // arg 1: output
      'createaddition:electrum_rod',
      'kubejs:microcircuit'
    ])
})
