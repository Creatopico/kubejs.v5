ServerEvents.recipes(event => {
    event.shapeless('1x kubejs:ammonia_bottle', [ // arg 1: output
      'minecraft:glass_bottle',
      'kubejs:guano'
    ])
})
