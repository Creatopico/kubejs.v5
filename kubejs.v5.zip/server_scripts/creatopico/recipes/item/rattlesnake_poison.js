ServerEvents.recipes(event => {
    event.shapeless('1x kubejs:rattlesnake_poison', [ // arg 1: output
      'minecraft:glass_bottle',
      'kubejs:dead_rattlesnake'
    ])
})
