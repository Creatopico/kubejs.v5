ServerEvents.recipes(event => {
    event.smelting('kubejs:processed_silicon', 'kubejs:quartzite_dust')
})