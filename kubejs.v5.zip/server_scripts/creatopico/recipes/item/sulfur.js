ServerEvents.recipes(event => {
    event.smelting('kubejs:sulfur', 'kubejs:guano')
})